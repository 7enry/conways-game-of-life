# -*- coding: utf-8 -*-
"""
The Game of Life (GoL) module named in honour of John Conway

This module defines the classes required for the GoL simulation.

@author: shakes

implemented by: henry bui
"""
import numpy as np
from scipy import signal
import rle
from rle import RunLengthEncodedParser # import rle class as required

class GameOfLife:
    '''
    Object for computing Conway's Game of Life (GoL) cellular machine/automata
    '''
    def __init__(self, N=256, finite=False, fastMode=False):
        self.grid = np.zeros((N,N), np.int64)
        self.neighborhood = np.ones((3,3), np.int64) # 8 connected kernel
        self.neighborhood[1,1] = 0 #do not count centre pixel
        self.finite = finite
        self.fastMode = fastMode
        self.aliveValue = 1
        self.deadValue = 0
        
    def getStates(self):
        '''
        Returns the current states of the cells
        '''
        return self.grid
    
    def getGrid(self):
        '''
        Same as getStates()
        '''
        return self.getStates()
               
    
    def evolve(self):
        '''
        Given the current states of the cells, apply the GoL rules:
        - Any live cell with fewer than two live neighbors dies, as if by underpopulation.
        - Any live cell with two or three live neighbors lives on to the next generation.
        - Any live cell with more than three live neighbors dies, as if by overpopulation.
        - Any dead cell with exactly three live neighbors becomes a live cell, as if by reproduction
        
        '''

        N = self.grid.shape[0] # number of rows/cols in the grid

        # new grid to be made after evolve
        new_grid = np.zeros_like(self.grid)

        if self.fastMode:
        #calculate number of live neighbours
            if self.finite: 
                neighbour_num = signal.convolve2d(self.grid, self.neighborhood, mode='same', boundary='fill')
            else: # wrap around (default)
                neighbour_num = signal.convolve2d(self.grid, self.neighborhood, mode='same', boundary='wrap')
        else:
            # section 1(a)
            neighbour_num = np.zeros_like(self.grid)
            for x in range(N):
                for y in range(N): 
                    count = 0
                    # create arrays to loop through all possible sides 
                    """
                       -1 0 1
                     1 [0 0 0]
                     0 [0 0 0]
                    -1 [0 0 0]
                    """
                    for dx in [-1, 0, 1]: # horizontal
                        for dy in [-1, 0, 1]: # vertical
                            if dx == 0 and dy == 0: #skip centre [0,0]
                                continue
                            ni, nj = x + dx, y + dy #next neighbour poisiton
                            if self.finite:
                                if 0 <= ni < N and 0 <= nj < N:
                                    count += self.grid[ni][nj]
                            else: #toroidal (wrap-around) boundaries
                                count += self.grid[ni % N][nj % N]
                    neighbour_num[x][y] = count #store neighbour count at position for GoL rules
    
        # GoL rules:
        # rule 1 & 3: underpopulation and overpopulation -> leave at zero
        # rule 2: survival condition -> change to one (alive)
        new_grid[(self.grid == self.aliveValue) & ((neighbour_num == 2) | (neighbour_num == 3))] = self.aliveValue
        # rule 4: reproduction -> change to one (alive)
        new_grid[(self.grid == self.deadValue) & (neighbour_num == 3)] = self.aliveValue
        self.grid = new_grid
                
    
    def insertBlinker(self, index=(0,0)):
        '''
        Insert a blinker oscillator construct at the index position
        '''
        self.grid[index[0], index[1]+1] = self.aliveValue
        self.grid[index[0]+1, index[1]+1] = self.aliveValue
        self.grid[index[0]+2, index[1]+1] = self.aliveValue
        
    def insertGlider(self, index=(0,0)):
        '''
        Insert a glider construct at the index position
        '''
        self.grid[index[0], index[1]+1] = self.aliveValue
        self.grid[index[0]+1, index[1]+2] = self.aliveValue
        self.grid[index[0]+2, index[1]] = self.aliveValue
        self.grid[index[0]+2, index[1]+1] = self.aliveValue
        self.grid[index[0]+2, index[1]+2] = self.aliveValue
        
    def insertGliderGun(self, index=(0,0)):
        '''
        Insert a glider construct at the index position
        '''
        self.grid[index[0]+1, index[1]+25] = self.aliveValue
        
        self.grid[index[0]+2, index[1]+23] = self.aliveValue
        self.grid[index[0]+2, index[1]+25] = self.aliveValue
        
        self.grid[index[0]+3, index[1]+13] = self.aliveValue
        self.grid[index[0]+3, index[1]+14] = self.aliveValue
        self.grid[index[0]+3, index[1]+21] = self.aliveValue
        self.grid[index[0]+3, index[1]+22] = self.aliveValue
        self.grid[index[0]+3, index[1]+35] = self.aliveValue
        self.grid[index[0]+3, index[1]+36] = self.aliveValue
        
        self.grid[index[0]+4, index[1]+12] = self.aliveValue
        self.grid[index[0]+4, index[1]+16] = self.aliveValue
        self.grid[index[0]+4, index[1]+21] = self.aliveValue
        self.grid[index[0]+4, index[1]+22] = self.aliveValue
        self.grid[index[0]+4, index[1]+35] = self.aliveValue
        self.grid[index[0]+4, index[1]+36] = self.aliveValue
        
        self.grid[index[0]+5, index[1]+1] = self.aliveValue
        self.grid[index[0]+5, index[1]+2] = self.aliveValue
        self.grid[index[0]+5, index[1]+11] = self.aliveValue
        self.grid[index[0]+5, index[1]+17] = self.aliveValue
        self.grid[index[0]+5, index[1]+21] = self.aliveValue
        self.grid[index[0]+5, index[1]+22] = self.aliveValue
        
        self.grid[index[0]+6, index[1]+1] = self.aliveValue
        self.grid[index[0]+6, index[1]+2] = self.aliveValue
        self.grid[index[0]+6, index[1]+11] = self.aliveValue
        self.grid[index[0]+6, index[1]+15] = self.aliveValue
        self.grid[index[0]+6, index[1]+17] = self.aliveValue 
        self.grid[index[0]+6, index[1]+18] = self.aliveValue # duplicate 17 changed to 18 (Gosper glider gun)
        self.grid[index[0]+6, index[1]+23] = self.aliveValue
        self.grid[index[0]+6, index[1]+25] = self.aliveValue
        
        self.grid[index[0]+7, index[1]+11] = self.aliveValue
        self.grid[index[0]+7, index[1]+17] = self.aliveValue
        self.grid[index[0]+7, index[1]+25] = self.aliveValue
        
        self.grid[index[0]+8, index[1]+12] = self.aliveValue
        self.grid[index[0]+8, index[1]+16] = self.aliveValue
        
        self.grid[index[0]+9, index[1]+13] = self.aliveValue
        self.grid[index[0]+9, index[1]+14] = self.aliveValue
        
    def insertFromPlainText(self, txtString, pad=0):
        '''
        Assumes txtString contains the entire pattern as a human readable pattern without comments
        '''
        pattern_lines = txtString.strip('\n').splitlines()

        # think of pad as the starting position / how much from the edge e.g. pad = 5 is (5,5)
        for x, line in enumerate(pattern_lines): # using enumerate for grid position
            if line.startswith('!'): # comments in txt form
                continue
            for y, char in enumerate(line):
                if char == 'O': # alive cells
                    self.grid[pad + x, pad + y] = self.aliveValue
                elif char == '.' or char == ' ': # dead cells
                    self.grid[pad + x, pad + y] = self.deadValue

    def insertFromRLE(self, rleString, pad=0):
        '''
        Given string loaded from RLE file, populate the game grid
        '''
        parseRLE = RunLengthEncodedParser(rleString) # does all filtering for you - given
        pattern = parseRLE.pattern_2d_array  # 2D list of 'b' (dead) and 'o' (alive)

        for x, row in enumerate(pattern):
            for y, cell in enumerate(row):
                if cell == 'o': # alive
                    self.grid[pad + x, pad + y] = self.aliveValue
                else:
                    self.grid[pad + x, pad + y] = self.deadValue

