# -*- coding: utf-8 -*-
"""
Game of life script with animated evolution

@author: shakes

implemented by: henry bui
"""
import conway


N = 64

# change file name as required
with open("txt.cells", "r") as text_file:
        cellString = text_file.read()      

#create the game of life object
life = conway.GameOfLife(N)

# life.insertBlinker((0,0))
#life.insertGlider((0,0))
#life.insertGliderGun((0,0))
life.insertFromPlainText(cellString, pad=20)
cells = life.getStates() #initial state

#-------------------------------
#plot cells
import matplotlib.pyplot as plt
import matplotlib.animation as animation

fig = plt.figure()

plt.gray()

img = plt.imshow(cells, animated=True)

def animate(i):
    """perform animation step"""
    global life
    
    life.evolve()
    cellsUpdated = life.getStates()
    
    img.set_array(cellsUpdated)
    
    return img,

interval = 200 #ms

#animate 24 frames with interval between them calling animate function at each frame
ani = animation.FuncAnimation(fig, animate, frames=24, interval=interval, blit=True)

plt.show()
