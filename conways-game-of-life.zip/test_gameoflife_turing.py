# -*- coding: utf-8 -*-
"""
Game of life script with animated evolution

@author: shakes

implemented by: henry bui
"""
import conway


N = 1750
padding = 10
#read RLE file -> change file name when needed
# with open("filename.rle", "r") as text_file:
#        rleString = text_file.read()

# N = 1750    
# # larger than 1024 as well   
with open("turingmachine.rle", "r") as text_file:
        rleString = text_file.read()

#create the game of life object
life = conway.GameOfLife(N, fastMode=True)
life.insertFromRLE(rleString, padding)
cells = life.getStates() #initial state



#-------------------------------
#plot cells
import matplotlib.pyplot as plt
import matplotlib.animation as animation

fig = plt.figure()

plt.gray()

img = plt.imshow(cells, animated=True)

def animate(i):
    """perform animation step"""
    global life
    
    life.evolve()
    cellsUpdated = life.getStates()
    
    img.set_array(cellsUpdated)
    
    return img,

interval = 50 #ms

#animate 24 frames with interval between them calling animate function at each frame
ani = animation.FuncAnimation(fig, animate, frames=24, interval=interval, blit=True)
#~ animate(0)

plt.show()
