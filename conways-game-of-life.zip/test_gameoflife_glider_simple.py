# -*- coding: utf-8 -*-
"""
Game of life simple script for checking init states and checking if the evolution is
implemented correctly.

@author: shakes

implemented by: henry bui
"""
import conway

N = 64

#create the game of life objects
life = conway.GameOfLife(N)
#life.insertBlinker((0,0))
#life.insertGlider((0,0))
life.insertGliderGun((0,0))

# testing insertFromPlainText() using string constants
gosperGlideGun = """
........................O...........
......................O.O...........
............OO......OO............OO
...........O...O....OO............OO
OO........O.....O...OO..............
OO........O...O.OO....O.O...........
..........O.....O.......O...........
...........O...O....................
............OO......................
"""
diamond4812 = """
....OOOO

..OOOOOOOO

OOOOOOOOOOOO

..OOOOOOOO

....OOOO
"""

#life.insertFromPlainText(diamond4812, pad=5)

cells = life.getStates() #initial state

#evolve once
life.evolve()
cellsUpdated1 = life.getStates()

#evolve twice
life.evolve()
cellsUpdated2 = life.getStates()

#used to check states over time (additional)
life.evolve()
cellsUpdated3 = life.getStates()
life.evolve()
cellsUpdated4 = life.getStates()
life.evolve()
cellsUpdated5 = life.getStates()
life.evolve()
cellsUpdated6 = life.getStates()

#-------------------------------
#plot cells
import matplotlib.pyplot as plt
import numpy as np

plt.figure(0)
plt.gray()
plt.imshow(cells)

ax = plt.gca()
# Minor ticks
ax.set_xticks(np.arange(-.5, N, 1), minor=True);
ax.set_yticks(np.arange(-.5, N, 1), minor=True);
#grid
ax.grid(which='minor', color='w', linestyle='-', linewidth=1)

plt.figure(1)
plt.imshow(cellsUpdated1)
#
plt.figure(2)
plt.imshow(cellsUpdated2)

# used to check states over time (additional)
plt.figure(3)
plt.imshow(cellsUpdated3)
plt.figure(4)
plt.imshow(cellsUpdated4)
plt.figure(5)
plt.imshow(cellsUpdated5)
plt.figure(6)
plt.imshow(cellsUpdated6)


plt.show()
